<div class="footer">
			<div class="copyright">
				<p><span>Online Auto Mechanic Finder</span> 2020 | All Right Reserved </p>
			</div>
		</div>

	</div>
	</div>
</body>
</html>