<html>
<head>
<title>Online Auto Mechanic Finder</title>
<link rel="stylesheet" href="../style.css">
<script type="text/javascript" src="../jquery.js"></script>
</head>
<body>
	<div class="container">
	<div class="wrapper">
		<div class="mynavbar">
			<div class="logo">
				<a href="adminhome.php"><p>Online<span> Auto Mechanic</span> Finder</p></a>
			</div>
			<div class="navcombo" style="width:">
			<div class="headernav" >
				<a href="userhome.php" style="color:#34a1eb">Home</a>
			</div>

			<div class="headernav" >
				<a href="findmacanic.php">Find Mechanics</a>
			</div>
			<div class="headernav">
				<a href="myrequest.php">My Requests</a>
			</div>

			<div class="logoutdiv headernav">
				<a id="logoutbtn" href='../logout.php'>Logout</a>
			</div>
		</div>
			</div>