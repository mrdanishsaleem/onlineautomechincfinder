<?php
include('adminheader.php');
?>
<div class="registrationbox">
<h2 style="height:600px; padding-top:20%;">Welcome to Admin Panel</h2>
</div>

<?php
	include('footer.php');
?>

